//class:civil FE
//Name:Shaikh Noorealam 
//UIN:251C006
//Divion:B

#include<stdio.h>
int main()
{
    printf("Name\t\t :Shaikh Noorealam\n");
    printf("Age\t\t :17\n");
    printf("Class\t\t :Civil FE\n");
    printf("Divion\t\t :B\n");
    printf("UIN\t\t :251C006\n");

    return 0;
}